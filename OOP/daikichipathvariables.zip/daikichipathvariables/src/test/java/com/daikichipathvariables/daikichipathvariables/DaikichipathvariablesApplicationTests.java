package com.daikichipathvariables.daikichipathvariables;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichipathvariablesApplicationTests {

	@Test
	void contextLoads() {
	}

}
