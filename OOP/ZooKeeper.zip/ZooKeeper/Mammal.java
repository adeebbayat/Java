
public class Mammal {
    double energyLevel = 100;

    public Mammal(){
        
    }

    public double displayEnergy(){
        return this.energyLevel;
    }
}
